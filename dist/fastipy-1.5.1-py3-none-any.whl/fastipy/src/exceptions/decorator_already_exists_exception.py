from .fastipy_base_exception import FastipyBaseException


class DecoratorAlreadyExistsException(FastipyBaseException):
    pass
