from .fastipy_exception import FastipyException


class InvalidPathException(FastipyException):
    pass
