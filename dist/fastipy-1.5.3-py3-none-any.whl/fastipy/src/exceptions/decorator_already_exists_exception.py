from .fastipy_exception import FastipyException


class DecoratorAlreadyExistsException(FastipyException):
    pass
