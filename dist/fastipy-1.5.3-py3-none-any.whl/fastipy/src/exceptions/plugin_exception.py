from .fastipy_exception import FastipyException


class PluginException(FastipyException):
    pass
