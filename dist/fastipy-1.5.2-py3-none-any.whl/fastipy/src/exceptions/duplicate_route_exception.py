from .fastipy_exception import FastipyException


class DuplicateRouteException(FastipyException):
    pass
