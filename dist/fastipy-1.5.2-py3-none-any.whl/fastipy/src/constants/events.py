from typing import Literal

eventType = Literal["startup", "shutdown"]
EVENTS = ["startup", "shutdown"]
