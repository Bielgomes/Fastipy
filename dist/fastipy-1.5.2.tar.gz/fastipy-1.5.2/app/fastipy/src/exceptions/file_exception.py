from .fastipy_exception import FastipyException


class FileException(FastipyException):
    pass
