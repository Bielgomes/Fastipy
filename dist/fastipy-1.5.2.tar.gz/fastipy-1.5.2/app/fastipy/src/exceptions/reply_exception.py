from .fastipy_exception import FastipyException


class ReplyException(FastipyException):
    pass
