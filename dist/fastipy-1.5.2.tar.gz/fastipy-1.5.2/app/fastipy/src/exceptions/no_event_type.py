from .fastipy_exception import FastipyException


class NoEventTypeException(FastipyException):
    pass
