from typing import Literal

httpMethodType = Literal['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD']
HTTP_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD']