from .fastipy_base_exception import FastipyBaseException

class InvalidPathException(FastipyBaseException):
  pass