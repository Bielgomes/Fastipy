from .fastipy_base_exception import FastipyBaseException

class NoEventTypeException(FastipyBaseException):
  pass