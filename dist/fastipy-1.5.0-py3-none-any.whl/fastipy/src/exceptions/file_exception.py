from .fastipy_base_exception import FastipyBaseException

class FileException(FastipyBaseException):
  pass