from .fastipy_base_exception import FastipyBaseException


class ReplyException(FastipyBaseException):
    pass
