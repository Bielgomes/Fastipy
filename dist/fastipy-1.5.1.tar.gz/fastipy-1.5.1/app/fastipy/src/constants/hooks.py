from typing import Literal

hookType = Literal["onRequest", "preHandler", "onResponse", "onError"]
HOOKS = ["onRequest", "preHandler", "onResponse", "onError"]
