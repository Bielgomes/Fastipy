from .fastipy_exception import FastipyException


class NoHTTPMethodException(FastipyException):
    pass
