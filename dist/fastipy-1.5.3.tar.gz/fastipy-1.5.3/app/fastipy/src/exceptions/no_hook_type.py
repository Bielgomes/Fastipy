from .fastipy_exception import FastipyException


class NoHookTypeException(FastipyException):
    pass
